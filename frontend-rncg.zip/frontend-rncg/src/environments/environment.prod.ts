// src/environments/environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://api.gastrosai.lat'
};
