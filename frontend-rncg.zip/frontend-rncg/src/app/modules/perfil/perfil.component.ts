import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.component.html',
  styleUrls: ['./perfil.component.scss']
})
export class PerfilComponent implements OnInit {
  user: any = null;
  showResetModal = false;
  resetEmail = '';
  newPassword = '';
  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      alert('⚠️ Debes iniciar sesión');
      this.router.navigate(['/login']);
      return;
    }
  
    const parsed = JSON.parse(storedUser);
    const userId = parsed.id;
  
    this.http.get(`${environment.apiUrl}/users/${userId}`).subscribe({
      next: (data) => {
        this.user = data;
      },
      error: () => {
        alert('❌ No se pudo cargar la información del perfil');
      }
    });
  }
  

  updateProfile(): void {
    this.http.put(`${environment.apiUrl}/users/${this.user.id}`, this.user).subscribe({
      next: () => {
        //alert('✅ Perfil actualizado correctamente');
        localStorage.setItem('user', JSON.stringify(this.user)); // Actualiza el localStorage
      },
      error: (err) => {
        console.error('❌ Error al actualizar perfil:', err);
        alert('❌ No se pudo actualizar el perfil');
      }
    });
  }

  logout(): void {
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
  }
  openResetModal() {
  this.showResetModal = true;
  }
  closeResetModal() {
  this.showResetModal = false;
  this.resetEmail = '';
  this.newPassword = '';
  }
  resetPassword(): void {
  const body = {
    resetEmail: this.resetEmail,
    newPassword: this.newPassword,
  };

  this.http.post(`${environment.apiUrl}/auth/reset-password`, body).subscribe({
    next: () => {
      alert('✅ Contraseña actualizada correctamente');
      this.showResetModal = false;
    },
    error: (err) => {
      console.error('❌ Error:', err);
      alert(err.error.message || '❌ No se pudo restablecer la contraseña.');
    }
  });
}
}
